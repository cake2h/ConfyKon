<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Confy</title>
    <!-- Styles -->
    <style>
        html {
            line-height: 1.15;
            -webkit-text-size-adjust: 100%
        }
        body {
            margin: 0;
            padding: 0;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        [hidden] {
            display: none
        }
        html {
            font-family: system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, Helvetica Neue, Arial, Noto Sans, sans-serif, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol, Noto Color Emoji;
            line-height: 1.5
        }
        *, :after, :before {
            box-sizing: border-box;
            border: 10 solid #e2e8f0
        }
        svg, video {
            display: block;
            vertical-align: middle
        }
        video {
            max-width: 100%;
            height: auto
        }
        .flex {
            display: flex
        }
        .hidden {
            display: none
        }
        .justify-center {
            justify-content: center
        }
        .items-top {
            align-items: center
        }
        .min-h-screen {
            min-height: 100vh
        }
        .fixed {
            position: fixed
        }
        .relative {
            position: relative
        }
        .antialiased {
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale
        }
        .centrate {
            margin-bottom: 10px;
            margin-top: 55px;
            margin-right: 100px;
            margin-left: 100px
        }
        .logo-main {
            padding-right: 15px;
            margin-right: 15px;
            border-right: 1px solid black;
        }
        .flex-images {
            display: flex;
            align-items: center;
        }
        .line {
            flex-direction: row;
        }
    </style>
    <style>
        .bg-ex-fixed{
            background: linear-gradient(-45deg, #24aaaf, #00aeef, #24aaaf, #fdaf7b);
            background-size: 900% 900%;
            animation: gradient 18s ease infinite;
            background-repeat: no-repeat;
            background-position: center;
            background-attachment: fixed; /* Закрепляем изображение */
        }
        @keyframes gradient {
            0% {
                background-position: 0% 50%;
            }
            50% {
                background-position: 100% 50%;
            }
            100% {
                background-position: 0% 50%;
            }
        }
    </style>
    <style>
        .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 100%;
            padding: 0px;
            background: rgba(203, 203, 203, 0.7);
            border-radius: 35px;
            margin: 25px 35px 25px 35px;
            flex-direction: column;
            position: relative;
            opacity: 0;
            animation: ani 1.5s forwards;
        }
        @keyframes ani {
            0% {
                opacity: 0;
            }
            100% {
                opacity: 1;
            }
        }
        .between {
            justify-content: space-between;
        }
        .otstup-r {
            margin-right: 10px;
        }
        .otstup-l {
            margin-left: 10px;
        }
        .btn-secondary {
            display: inline-block;
            text-decoration: none;
            width: 150px;
            height: 60px;
            border-radius: 40px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
            line-height: 60px;
            vertical-align: middle;
            text-align: center;
            background-color: #00aeef;
            color: #fff;
        }
        .btn-secondary:hover {
            display: inline-block;
            box-shadow: 0 0 0 rgba(0, 0, 0, 0);
            background: rgba(255, 0, 59);
            transition: background;
        }
        .btn3 {
            display: inline-block;
            text-decoration: none;
            width: 240px;
            height: 40px;
            border-radius: 12px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
            line-height: 40px;
            vertical-align: middle;
            text-align: center;
            background-color: #c0d6f0;
            color: #fff;
        }
        .btn3:hover {
            display: inline-block;
            box-shadow: 0 0 0 rgba(0, 0, 0, 0);
            background: #00aeef;
            transition: background;
        }

        
        @media screen and (max-width: 650px) {
            .btn-secondary {
                display: none;
            }
            .btn3 {
                display: none;
            }
            .logo-main {
                display: none;
            }
            header {
                display: none;
            }
        }
        header {
            width: 100%;
            height: 80px;
            border-radius: 35px;
            padding: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
            margin-bottom: 60px;
        }
        .under {
            width: 100%;
            height: 80px;
            border-radius: 35px;
            padding: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
            margin-bottom: auto;
        }
        body {
            font-family: Trebuchet MS, sans-serif;
        }
    </style>
    <style>
        .square {
            display: flex;
            width: 100%;
            height: 460px;
            padding: 8px;
            margin-bottom: 60px;
            transition: height 0.5s ease;
        }
        .stick1 {
            width: 19%;
            height: 80px;
            border-radius: 25px;
            padding: 8px;
            background: white;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
            margin-bottom: 60px;
            vertical-align: middle;
            text-align: center;
            color:#23a6ab;
        }
        .stick2 {
            width: 460px;
            height: 300px;
            border-radius: 25px;
            background: white;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
            margin-bottom: 60px;
            line-height: 30px;
            overflow: hidden;
            vertical-align: middle;
            color:#23a6ab;
            transition: height 0.5s ease;
        }
        .margin-none {
            margin: 0px 20px 0px 20px;
        }
    </style>
</head>
<body class="antialiased ">
<div class="relative flex items-top justify-center min-h-screen bg-gray-100 dark:bg-gray-900 sm:items-center py-4 sm:pt-0 bg-ex-fixed">
    <div class="container">
        <header class="flex between">
            <div class="flex-images">
                <a href="https://www.utmn.ru/" class="logo-main otstup-l"><img src="https://www.utmn.ru/upload/medialibrary/47f/logo_utmn_mini2_rus.png" alt="ТюмГУ" width="120"/></a>
                <a href="https://www.utmn.ru/bmm/"><img src="https://www.utmn.ru/local/templates/bmm/layout/dist/assets/img/%D0%B1%D0%BC%D0%BC.svg" alt="БММ" width="120"></a>
            </div>
            <div class="hidden flex-images">
                <nav>
                    <a href="{{ route('konf.index') }}" class="btn-secondary otstup-r">Конференции</a>
                    
                    <a href="#" class="btn-secondary" onclick="event.preventDefault(); document.getElementById('logoutForm').submit();">Выход</a>
                    <form method="POST" action="{{ route('logout') }}" id="logoutForm" style="display: none;">
                        @csrf
                    </form>
                </nav>
            </div>
        </header>
        
        
      


          <div class="square line">
              <div id="stick2" class="stick2">
                      <div style="vertical-align: none; line-height: 30px;" class="margin-none">
                          <h2>{{$data->name}}</h2>
                          <p><strong>Почта:</strong> {{$data->email}}</p>
                          <p><strong>Год рождения:</strong> {{$data->age}}</p>
                          <p><strong>Город:</strong> {{$data->city}}</p>
                          <p><strong>Научная степень:</strong> {{$data->science_level}}</p>
                          <p><strong>Место учебы:</strong> {{$data->study_place}}</p>
                      </div>
              </div>
          </div>
          @foreach($conferences as $conference)
               
                    {{ $conference->name }}
                    {{ $conference->country }}
                    {{ $conference->city }}
                    {{ $conference->date_start }}
                    {{ $conference->date_end }}
                    {{ $conference->deadline }}
                    {{ $conference->description }}
                   
                  
               
            @endforeach
        <div class="under" ></div>
    </div>
    <script>
    </script>
</div>
</body>
</html>






