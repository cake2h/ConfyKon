@foreach ($konfs as $konf)
            
    
            <form method="POST" action="{{ route('upkon',  ['id' => $konf->id]) }}">
        @csrf
        <label for="name">Name:</label>
        <input type="text" name="name" required value="{{$konf->name}}"><br>

        <label for="country">Country:</label>
        <input type="text" name="country" required value="{{$konf->country}}"><br>

        <label for="city">City:</label>
        <input type="text" name="city" required value="{{$konf->city}}"><br>

        <label for="date_start">Date Start:</label>
        <input type="date" name="date_start" required value="{{$konf->date_start}}"> <br>

        <label for="date_end">Date End:</label>
        <input type="date" name="date_end" required value="{{$konf->date_end}}"><br>

        <label for="deadline">Deadline:</label>
        <input type="text" name="deadline" required value="{{ $konf->deadline}}"><br>

        <label for="description">Description:</label>
        <textarea name="description" required value="{{$konf->description}}">{{$konf->description}}</textarea><br>

        <button type="submit">Изменить</button>
    </form>
        @endforeach