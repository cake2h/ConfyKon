<form method="POST" action="{{ route('logout') }}" id="logoutForm">
                @csrf
                <button class="btn btn-primary" type="submit">
                    {{ __('Выйти') }}
                </button>
            </form>
            <a href="{{ route('addkonf') }}" class="btn btn-secondary">
                {{ __('Добавить мероприяти') }}
            </a>
            <h2>Conference List</h2>
    <ul>
        @foreach ($konfs as $konf)
            <li><a  href="{{route('updatekonf', $konf['id'])}}">
                <strong>{{ $konf->name }}</strong><br>
                Country: {{ $konf->country }}<br>
                City: {{ $konf->city }}<br>
                Date Start: {{ $konf->date_start }}<br>
                Date End: {{ $konf->date_end }}<br>
                Deadline: {{ $konf->deadline }}<br>
                Description: {{ $konf->description }}<br>
</a>
                <a href="{{route('delete', $konf['id'])}}" >Удалить</a>
            </li>
        @endforeach
    </ul>