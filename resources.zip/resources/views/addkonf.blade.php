<!-- resources/views/konf.blade.php -->

<!DOCTYPE html>
<html>
<head>
    <title>Conference List</title>
</head>
<body>
    <h1>Conference List</h1>

    <!-- Форма для добавления новой конференции -->
    <form method="POST" action="{{ route('konf.store',  ['id' => $konf->id]) }}">
        @csrf
        <label for="name">Name:</label>
        <input type="text" name="name" required><br>

        <label for="country">Country:</label>
        <input type="text" name="country" required><br>

        <label for="city">City:</label>
        <input type="text" name="city" required><br>

        <label for="date_start">Date Start:</label>
        <input type="date" name="date_start" required><br>

        <label for="date_end">Date End:</label>
        <input type="date" name="date_end" required><br>

        <label for="deadline">Deadline:</label>
        <input type="text" name="deadline" required><br>

        <label for="description">Description:</label>
        <textarea name="description" required></textarea><br>

        <button type="submit">Submit</button>
    </form>

    <hr>

    <!-- Вывод списка конференций -->
    
</body>
</html>
